import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const { Schema, model } = mongoose;
const schemas = {
  buses: new Schema({ busNumber: { type: String, required: true }, busName: String, capacity: { type: Number, default: 40 }, status: { type: String, enum: ['Active','Inactive','Maintenance'], default: 'Active' }, driver: String, routeName: String }, { timestamps: true }),
  routes: new Schema({ routeCode: { type: String, required: true }, routeName: { type: String, required: true }, startPoint: String, endPoint: String, stopNames: [String], departureTime: String, arrivalTime: String }, { timestamps: true }),
  stops: new Schema({ stopName: { type: String, required: true }, location: String, routes: [String], arrivalTime: String }, { timestamps: true }),
  drivers: new Schema({ name: { type: String, required: true }, phone: String, licenseNumber: String, busNumber: String, status: { type: String, default: 'Available' } }, { timestamps: true })
};
const models = Object.fromEntries(Object.entries(schemas).map(([key, schema]) => [key, model(key[0].toUpperCase()+key.slice(1), schema)]));
app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'Campus Transport API' }));
for (const [resource, Model] of Object.entries(models)) {
  const route = `/api/${resource}`;
  app.get(route, async (_req, res, next) => { try { res.json(await Model.find().sort({ createdAt: -1 })); } catch(e) { next(e); } });
  app.post(route, async (req, res, next) => { try { res.status(201).json(await Model.create(req.body)); } catch(e) { next(e); } });
  app.get(`${route}/:id`, async (req, res, next) => { try { const doc = await Model.findById(req.params.id); if (!doc) return res.status(404).json({ message: 'Record not found' }); res.json(doc); } catch(e) { next(e); } });
  app.put(`${route}/:id`, async (req, res, next) => { try { const doc = await Model.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true }); if (!doc) return res.status(404).json({ message: 'Record not found' }); res.json(doc); } catch(e) { next(e); } });
  app.delete(`${route}/:id`, async (req, res, next) => { try { const doc = await Model.findByIdAndDelete(req.params.id); if (!doc) return res.status(404).json({ message: 'Record not found' }); res.json({ message: 'Deleted successfully' }); } catch(e) { next(e); } });
}
app.use((err, _req, res, _next) => res.status(400).json({ message: err.message || 'Request failed' }));
const port = process.env.PORT || 5000;
try {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/campus_transport');
  console.log('Connected to MongoDB');
  app.listen(port, () => console.log(`Campus Transport API running on http://localhost:${port}`));
} catch (err) {
  console.error('MongoDB connection failed:', err.message);
  process.exit(1);
}

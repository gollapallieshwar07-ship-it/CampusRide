# Campus Transport Tracking System — MERN Prototype

A starter MERN project for managing campus buses, routes, stops, drivers, and schedules.

## Requirements
- Node.js 18+
- MongoDB running locally, or a MongoDB Atlas connection string

## Run backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```
Backend runs at http://localhost:5000. Set `MONGO_URI` in `.env`.

## Run frontend
In a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite (usually http://localhost:5173).

## Prototype features
- Dashboard summary cards
- CRUD management for buses, routes, stops, and drivers
- Express REST API with MongoDB/Mongoose models
- Demo role selector (Admin / Student / Driver) for UI walkthrough

## Important limitations
This is a student project starter, not production-ready tracking. The role selector is only a UI demo; it is not secure authentication. Live GPS, real ETA calculations, password hashing, JWT/session authentication, and server-side role authorization must be added before real deployment. Do not enter real personal data.
